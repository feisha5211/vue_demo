export const displayArticle = ({ dispatch },show) => {
	dispatch('DISPLAY_ARTICLE',show)
}
