# vue-demo-jianshu

##项目结构
![image](https://github.com/Mrjeff578575/markdownphoto/blob/master/%E9%A1%B9%E7%9B%AE%E7%BB%93%E6%9E%84.jpg)

##项目简介
采用vue vue-router vuex实现简书的基本界面和功能

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# run unit tests
npm run unit

# run e2e tests
npm run e2e

# run all tests
npm test
```

For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
