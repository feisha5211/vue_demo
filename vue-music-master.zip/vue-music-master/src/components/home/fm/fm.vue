<template>
    <div class="fm">
        <h1 style="text-align:center;height: 500px;padding:100px;color: #3d3d3d;font-size:12px">正在施工中...</h1>
    </div>
</template>

<script>
    export default {

    }
</script>

<style>
    
</style>