 FOLLOW A KUGOU
----------------

vuejs仿写酷狗音乐webapp
-----------------

由于接口跨域，所以可下载到本地开发模式下预览

项目截图：
----
![](http://p1.bqimg.com/567571/3c5a913634588182.png)<br><br>
![](http://p1.bqimg.com/567571/95d8eca41b39fbcf.png)<br><br>
![](http://p1.bqimg.com/567571/4f2f5522d5403c5d.png)<br><br>
![](http://p1.bqimg.com/567571/b05a4d612b40baca.png)<br><br>

如何使用
----

 1. 下载本项目到本地
 2. npm install 安装依赖
 3. npm run dev 启动本地开发
