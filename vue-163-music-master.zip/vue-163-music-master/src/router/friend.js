import Home from 'components/friend/home'

export default{
  path: '/friend',
  component: Home
}
