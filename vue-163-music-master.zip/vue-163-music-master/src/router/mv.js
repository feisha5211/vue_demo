import Home from 'components/mv/home'

export default{
  path: '/mv',
  component: Home
}
