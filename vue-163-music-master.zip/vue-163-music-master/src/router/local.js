import Home from 'components/local/home'

export default{
  path: '/local',
  component: Home
}
