import Home from 'components/singer/home'

export default{
  path: '/singer',
  component: Home
}
