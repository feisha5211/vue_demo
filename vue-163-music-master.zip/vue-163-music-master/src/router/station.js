import Home from 'components/station/home'

export default{
  path: '/station',
  component: Home
}
