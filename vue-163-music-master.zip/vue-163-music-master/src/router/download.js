import Home from 'components/download/home'

export default{
  path: '/download',
  component: Home
}
