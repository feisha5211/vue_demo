import Home from 'components/playlist/home'

export default{
  path: '/playlist/:id',
  component: Home
}
