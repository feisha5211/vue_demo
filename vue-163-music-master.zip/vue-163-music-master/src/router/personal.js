import Home from 'components/personal/home'

export default{
  path: '/personal',
  component: Home
}
