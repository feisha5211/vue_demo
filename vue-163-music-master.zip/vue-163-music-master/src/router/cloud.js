import Home from 'components/cloud/home'

export default{
  path: '/cloud',
  component: Home
}
