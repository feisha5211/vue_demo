<template>
    <div>
      {{$route.path}}
    </div>
</template> 
<script>
export default{
}
</script>
<style scoped>
    
</style>
